package com.vn.ntesco.fragment


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

import com.vn.ntesco.R
import com.vn.ntesco.activity.AccountActivity
import com.vn.ntesco.activity.DetailNotificationActivity
import com.vn.ntesco.adapter.NotificationAdapter
import com.vn.ntesco.base.BaseFragment
import com.vn.ntesco.listener.EndlessRecyclerOnScrollListener
import com.vn.ntesco.listener.ItemClickListener
import com.vn.ntesco.model.Notification
import com.vn.ntesco.model.Request.NTescoRequestGET
import com.vn.ntesco.model.Response.NotificationResponse
import com.vn.ntesco.network.NTescoService
import com.vn.ntesco.network.ServiceFactory
import com.vn.ntesco.utils.Constant
import com.vn.ntesco.utils.UserCache
import rx.Observer
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers


class NotificationFragment : BaseFragment(), SwipeRefreshLayout.OnRefreshListener {


    private lateinit var notificationAdapter: NotificationAdapter
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var rvNotify: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var endlessRecyclerOnScrollListener: EndlessRecyclerOnScrollListener
    private lateinit var tvNodata: TextView
    var from_home = false

    override fun getLayoutResource(): Int {
        return R.layout.fragment_notification
    }

    companion object {
        fun newInstance(fromHome: Boolean): NotificationFragment {
            val notificationFragment = NotificationFragment()
            // Bundle args = new_process Bundle();
            notificationFragment.from_home = fromHome
            //  truckInformationFragment.setArguments(args);
            return notificationFragment
        }
    }

    override fun onSetBodyView(view: View, container: ViewGroup?, savedInstanceState: Bundle?) {
        rvNotify = view.findViewById(R.id.rvNotify)
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout)
        tvNodata = view.findViewById(R.id.tvNodata)
        notificationAdapter = NotificationAdapter(activity)
        linearLayoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        rvNotify.apply {
            setHasFixedSize(true)
            adapter = notificationAdapter
            layoutManager = linearLayoutManager
        }

        notificationAdapter.setOnItemClickListener(object : ItemClickListener {
            override fun <T : Any> onItemClick(item: T, position: Int) {
                if (UserCache.isLogin()) {
                    val intent = Intent(activity, DetailNotificationActivity::class.java)
                    intent.putExtra(Constant.NOTIFICATION_ID, (item as Notification).id)
                    intent.putExtra(Constant.NOTIFICATION_STATUS, (item as Notification).status)
                    intent.putExtra(Constant.FROM_HOME, from_home)
                    startActivity(intent)
                    if (notificationAdapter.notificationsList[position].status == 1) {
                        notificationAdapter.notificationsList[position].status = 2
                        notificationAdapter.notifyItemChanged(position)
                    }
                } else {
                    val intent = Intent(activity, AccountActivity::class.java)
                    startActivity(intent)
                }

            }

        })
        getNotification(Constant.DEFAULT_FIRST_PAGE)
        endlessRecyclerOnScrollListener = object : EndlessRecyclerOnScrollListener(linearLayoutManager, Constant.DEFAULT_FIRST_PAGE) {
            override fun onLoadMore(current_page: Int) {
                getNotification(current_page)

            }

        }
        rvNotify.addOnScrollListener(endlessRecyclerOnScrollListener);
        swipeRefreshLayout.setOnRefreshListener(this)
        registerBroadcast(loginBroadcastReceiver, Constant.LOGIN_LOCAL_BROADCAST)
        registerBroadcast(notifyReceiver, Constant.NOTIFY_LOCAL_BROADCAST)

    }

    override fun onRefresh() {
        swipeRefreshLayout.isRefreshing = false
        endlessRecyclerOnScrollListener?.resetCurrentPage()
        getNotification(Constant.DEFAULT_FIRST_PAGE)
    }

    private fun getNotification(page: Int) {
        if (!UserCache.isLogin()) return
        setLoading(true)
        val nTescoRequestGET = NTescoRequestGET()
        nTescoRequestGET.setPage(page)
        ServiceFactory.createRetrofitService(NTescoService::class.java, Constant.apiEndPoint)
                .getNotifications(nTescoRequestGET)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe(object : Observer<NotificationResponse> {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        setLoading(false)
                    }

                    override fun onNext(notificationResponse: NotificationResponse) {
                        setLoading(false)
                        if (notificationResponse.code == Constant.SUCCESS) {
                            notificationResponse.data?.data?.let {
                                if (page == Constant.DEFAULT_FIRST_PAGE) {
                                    if (notificationResponse.data.data.size == 0)
                                        tvNodata.visibility = View.VISIBLE
                                    else
                                        tvNodata.visibility = View.GONE
                                    notificationAdapter.notificationsList = it
                                } else
                                    notificationAdapter.notificationsList.addAll(it)
                                notificationAdapter.notifyDataSetChanged()
                            }


                        }

                    }

                })

    }

    internal var loginBroadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            onRefresh()
        }
    }
    internal var notifyReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getBooleanExtra(Constant.FROM_NOTIFY, false))
                if (intent.getIntExtra(Constant.NOTIFICATION_ID, 0) != 0) {
                    val notifyId = intent.getIntExtra(Constant.NOTIFICATION_ID, 0)
                    for ((index, value) in notificationAdapter.notificationsList.withIndex()) {
                        if (value.id == notifyId) {
                            notificationAdapter.notificationsList[index].status = 2
                            notificationAdapter.notifyItemChanged(index)
                            break
                        }
                    }
                } else
                    onRefresh()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterBroadcast(loginBroadcastReceiver)
        unregisterBroadcast(notifyReceiver)
    }

}
