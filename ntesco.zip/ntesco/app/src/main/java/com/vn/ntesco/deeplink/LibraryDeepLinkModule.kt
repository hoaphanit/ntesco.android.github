package com.vn.ntesco.deeplink

import com.airbnb.deeplinkdispatch.DeepLinkModule

@DeepLinkModule
public class LibraryDeepLinkModule {
}