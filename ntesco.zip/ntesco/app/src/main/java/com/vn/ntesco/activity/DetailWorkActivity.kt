package com.vn.ntesco.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.widget.DatePicker
import android.widget.TextView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.vn.ntesco.R
import com.vn.ntesco.adapter.WorkCheckAdapter
import com.vn.ntesco.adapter.WorkImageAdapter
import com.vn.ntesco.base.BaseHeaderActivity
import com.vn.ntesco.fragment.WorkaroundMapFragment
import com.vn.ntesco.model.Report
import com.vn.ntesco.model.Request.NTescoRequestGET
import com.vn.ntesco.model.Request.NTescoRequestPOST
import com.vn.ntesco.model.Request.SignupRequest
import com.vn.ntesco.model.Response.NTescoResponse
import com.vn.ntesco.model.Response.ReportDetailReponse
import com.vn.ntesco.model.Response.UserResponse
import com.vn.ntesco.network.NTescoService
import com.vn.ntesco.network.ServiceFactory
import com.vn.ntesco.utils.*
import kotlinx.android.synthetic.main.activity_detail_work.*
import kotlinx.android.synthetic.main.list_work_item.*

import rx.Observer
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.RecyclerView
import android.widget.ImageView
//import com.asksira.bsimagepicker.Utils
import com.google.android.gms.maps.CameraUpdate
import com.google.android.gms.maps.model.*
import com.vn.ntesco.listener.ItemClickListener
import com.vn.ntesco.views.NtescoInfoWindowAdapter
import kotlinx.android.synthetic.main.activity_detail_report.*
import java.util.ArrayList


class DetailWorkActivity : BaseHeaderActivity(), OnMapReadyCallback {
    lateinit var waterTypeAdapter: WorkCheckAdapter
    lateinit var productTypeAdapter: WorkCheckAdapter
    lateinit var reportImageAdapter: WorkImageAdapter
    private var report: Report? = null
    // private var reportDetail: ReportDetail? = null
    private var mMap: GoogleMap? = null
    private val ZOOM_VALUE = 15
    private var reportId = 0
    private lateinit var newStatus: ImageView
    private lateinit var confirmStatus: ImageView
    private lateinit var processingStatus: ImageView
    private lateinit var completedStatus: ImageView

    override fun setTitle(): String {
        return ""
    }

    override fun getLayoutContent(): Int {
        return R.layout.activity_detail_work
    }

    override fun setBackgroundHeader(): Int {
        return UserCache.getColorUser()
    }

    override fun setBody(savedInstanceState: Bundle?) {
        super.setBody(savedInstanceState)
        report = intent.getSerializableExtra(Constant.REPORT) as? Report
        reportId = intent.getIntExtra(Constant.REPORT_ID, 0)
        WriteLog.e("reportId", reportId.toString())


        newStatus = findViewById<ImageView>(R.id.newStatus)
        confirmStatus = findViewById<ImageView>(R.id.confirm)
        processingStatus = findViewById<ImageView>(R.id.processing)
        completedStatus = findViewById<ImageView>(R.id.completed)

        val mMapFragment = supportFragmentManager.findFragmentById(R.id.map) as WorkaroundMapFragment
        mMapFragment.getMapAsync(this)
        if (PrefUtils.getInstance().getListProduct()?.size == 0)
            getProduct()
        if (PrefUtils.getInstance().getListWaterType()?.size == 0)
            getRawWaterType()
        waterTypeAdapter = WorkCheckAdapter(this)
        productTypeAdapter = WorkCheckAdapter(this)
        reportImageAdapter = WorkImageAdapter(this)
        reportImageAdapter.itemClickListener = object :ItemClickListener{
            override fun <T : Any> onItemClick(item: T, position: Int) {
                var intent = Intent(this@DetailWorkActivity,ViewImageActivity::class.java)
                intent.putExtra(Constant.LIST_IMAGE,reportImageAdapter.dataList as ArrayList<String>)
                startActivity(intent);
            }

        }
        val waterTypeLayoutManager = GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false)
        rvWaterType.apply {
            setHasFixedSize(true)
            adapter = waterTypeAdapter
            layoutManager = waterTypeLayoutManager
            waterTypeAdapter.dataList = PrefUtils.getInstance().getListWaterType()
            waterTypeAdapter.notifyDataSetChanged()
        }
        val productLayoutManager = GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false)
        rvProducts.apply {
            setHasFixedSize(true)
            adapter = productTypeAdapter
            layoutManager = productLayoutManager
            productTypeAdapter.dataList = PrefUtils.getInstance().getListProduct()
            productTypeAdapter.notifyDataSetChanged()
        }

        val reportImageLayoutManager = LinearLayoutManager(this, GridLayoutManager.HORIZONTAL, false)
        rvErrorReport.apply {
            setHasFixedSize(true)
            adapter = reportImageAdapter
            layoutManager = reportImageLayoutManager
        }
        mMapFragment.setListener(object : WorkaroundMapFragment.OnTouchListener {
            override fun onTouch() {
                scrollView.requestDisallowInterceptTouchEvent(true);
            }
        })

        btnConfirm.setOnClickListener(this)
        // ivNextWork.setOnClickListener(this)
        // ivPreviousWork.setOnClickListener(this)
        rvErrorReport.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                if (reportImageAdapter.dataList.size >= 3) {
                    val position = reportImageLayoutManager?.findLastCompletelyVisibleItemPosition();
                    val numItems = recyclerView.getAdapter()?.getItemCount();
                    WriteLog.e("isLastVisible", numItems.toString())
                    WriteLog.e("isLastVisible", position.toString())

                    if (position == 0) {
                        ivPreviousWork.visibility = View.GONE
                    } else {
                        ivPreviousWork.visibility = View.VISIBLE
                    }
                    if (position + 1 >= numItems!!) {
                        ivNextWork.visibility = View.GONE
                    } else {
                        ivNextWork.visibility = View.VISIBLE
                    }
                } else {
                    ivPreviousWork.visibility = View.GONE
                    ivNextWork.visibility = View.GONE
                }
            }
        })
//        if (report != null) {
//            titleHeader.text = getString(R.string.report) + " (" + report?.publishDate + ")"
//            if (UserCache.isCustomerUser()) {
//                btnConfirm.visibility = View.GONE
//                if (report?.status != ReportStatus.CONFIRM.status) {
//                    tvToDate.visibility = View.GONE
//                    tvFromDate.visibility = View.GONE
//                    labelDateMaintenance.visibility = View.GONE
//                }
//            } else {
//                when (report?.status) {
//                    ReportStatus.CONFIRM.status -> {
//                        btnConfirm.text = getString(R.string.complete)
//                        if (report?.mine!!) {
//                            btnConfirm.visibility = View.VISIBLE
//                        } else {
//                            btnConfirm.visibility = View.GONE
//                        }
//                    }
//                    ReportStatus.COMPLETED.status -> {
//                        btnConfirm.visibility = View.GONE
//                    }
//                    else -> {
//                        tvFromDate.setOnClickListener(this)
//                        tvToDate.setOnClickListener(this)
//
//                    }
//                }
//            }
//
//        }


    }

    override fun onMapReady(googleMap: GoogleMap?) {
        mMap = googleMap
        //   googleMap?.getUiSettings()?.setZoomGesturesEnabled(false)
        if (report != null)
            getReportDetail(report?.id)
        if (reportId != 0)
            getReportDetail(reportId)

    }

    private fun getReportDetail(id: Int?) {
        setLoading(true)
        var ntescoRequest = NTescoRequestGET()
        ServiceFactory.createRetrofitService(NTescoService::class.java, Constant.apiEndPoint)
                .getDetailReport(id.toString(), ntescoRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe(object : Observer<ReportDetailReponse> {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        setLoading(false)
                    }

                    override fun onNext(reportDetailReponse: ReportDetailReponse) {
                        setLoading(false)
                        if (reportDetailReponse.code == Constant.SUCCESS) {
                            report = reportDetailReponse.data
                            initData(report)
                        }

                    }

                })
    }

    fun initData(reportDetail: Report?) {
        if (reportDetail == null) return
        titleHeader.text = getString(R.string.report) + " (" + reportDetail?.createdAt + ")"
        if (UserCache.isCustomerUser()) {
            btnConfirm.visibility = View.GONE
            if (reportDetail?.status == ReportStatus.NOT_CONFIRM.status) {
                // tvToDate.visibility = View.GONE
                //  tvFromDate.visibility = View.GONE
                labelDateMaintenance.visibility = View.GONE
            }

        } else {
            when (reportDetail?.status) {
                ReportStatus.CONFIRM.status -> {
                    btnConfirm.text = getString(R.string.complete)
                    if (reportDetail?.mine) {
                        btnConfirm.visibility = View.VISIBLE
                    } else {
                        btnConfirm.visibility = View.GONE
                    }
                }
                ReportStatus.PROCESSING.status -> {
                    btnConfirm.text = getString(R.string.complete)
                    if (reportDetail?.mine) {
                        btnConfirm.visibility = View.VISIBLE
                    } else {
                        btnConfirm.visibility = View.GONE
                    }
                }
                ReportStatus.COMPLETED.status -> {
                    btnConfirm.visibility = View.GONE
                }
                else -> {
                    tvFromDate.setOnClickListener(this)
                    tvToDate.setOnClickListener(this)

                }
            }
        }
        when (reportDetail.status) {
            Constant.NEW -> {
                newStatus.setImageResource(R.mipmap.new_blue)

            }
            Constant.CONFIRM -> {
                newStatus.setImageResource(R.mipmap.new_blue)
                confirmStatus.setImageResource(R.mipmap.confirmed_blue)


            }
            Constant.PROCESSING -> {
                sendBroadcast(ReportStatus.COMPLETED.status)
                newStatus.setImageResource(R.mipmap.new_blue)
                confirmStatus.setImageResource(R.mipmap.confirmed_blue)
                processingStatus.setImageResource(R.mipmap.processing_blue)

            }
            Constant.COMPLETED -> {
                newStatus.setImageResource(R.mipmap.new_blue)
                confirmStatus.setImageResource(R.mipmap.confirmed_blue)
                processingStatus.setImageResource(R.mipmap.processing_blue)
                completedStatus.setImageResource(R.mipmap.completed_blue)


            }
        }
        tvCustomerName.setText(reportDetail.customerName)
        tvContentReport.setText(reportDetail.error)
        productTypeAdapter.dataList = reportDetail.products
        productTypeAdapter.notifyDataSetChanged()
        waterTypeAdapter.dataList = reportDetail.rawWaterType
        waterTypeAdapter.notifyDataSetChanged()
        if (reportDetail.images.size > 0) {
            reportImageAdapter.dataList = reportDetail.images
            reportImageAdapter.notifyDataSetChanged()
        } else {
            rvErrorReport.visibility = View.GONE
        }

        val customerLocation = LatLng(reportDetail.lat ?: 0.0, reportDetail.lng ?: 0.0)
        mMap?.setInfoWindowAdapter(NtescoInfoWindowAdapter(reportDetail?.address ?: "", this));
        mMap?.addMarker(MarkerOptions().position(customerLocation).title(reportDetail?.address
                ?: "").icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_location_blue)))
        if (!UserCache.isManager()) {
            mMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(customerLocation, ZOOM_VALUE.toFloat()))
        } else {
            if (reportDetail.status != ReportStatus.NOT_CONFIRM.status && reportDetail.employeeLat != null && reportDetail.employeeLng != null) {
                val employeeLocation = LatLng(reportDetail.employeeLat
                        ?: 0.0, reportDetail.employeeLng ?: 0.0)
                val employMarker = mMap?.addMarker(MarkerOptions().position(employeeLocation).icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_location_red)))
                val builder = LatLngBounds.Builder()
                builder.include(customerLocation)
                builder.include(employeeLocation)
                val bounds = builder.build()
                mMap?.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, resources.getDimensionPixelSize(R.dimen.padding_large)));
                mMap?.setOnMarkerClickListener(object : GoogleMap.OnMarkerClickListener {
                    override fun onMarkerClick(marker: Marker): Boolean {
                        if (marker.id.equals(employMarker?.id))
                            marker.hideInfoWindow();
                        else
                            marker.showInfoWindow();
                        return true;
                    }

                });
            } else {
                mMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(customerLocation, ZOOM_VALUE.toFloat()))
            }
        }

        if (reportDetail.status != ReportStatus.NOT_CONFIRM.status) {
            tvToDate.text = reportDetail.toDate
            tvFromDate.text = reportDetail.fromDate
        }

        if (UserCache.isManager()) {
            btnConfirm.visibility = View.VISIBLE
            if (reportDetail.status == 1) {
                btnConfirm.text = getString(R.string.confirm)
            }
            if (reportDetail.status == ReportStatus.PROCESSING.status ) {
                if(reportDetail.mine == true){
                    btnConfirm.visibility = View.VISIBLE
                    btnConfirm.text = getString(R.string.complete)
                }else{
                    btnConfirm.visibility = View.GONE
                }
            }
        } else {
//            btnConfirm.visibility = View.VISIBLE
//
            if (reportDetail.status == ReportStatus.PROCESSING.status && reportDetail.mine == true) {
                btnConfirm.visibility = View.VISIBLE
                btnConfirm.text = getString(R.string.complete)

            }else{
                btnConfirm.visibility = View.GONE
            }
        }
        if (reportDetail.status == ReportStatus.COMPLETED.status||reportDetail.status == ReportStatus.CONFIRM.status) {
            btnConfirm.visibility = View.GONE
        }
        if (reportDetail.status == 1) {
            btnConfirm.visibility = View.VISIBLE
            btnConfirm.text = getString(R.string.confirm)
        }

    }

    /*  fun calculateZoomLevel(): Int {
          var equatorLength: Double = 40075004.0
          var widthInPixels: Int = DimensionUtils.getWidthScreen();
          var metersPerPixel = equatorLength / 256;
          var zoomLevel = 1;
          while ((metersPerPixel * widthInPixels) > 2000) {
              metersPerPixel /= 2;
              ++zoomLevel;
          }
          return zoomLevel;
      }
  */
    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.tvFromDate -> {
                if (tvToDate.text.toString().isEmpty())
                    DialogUtils.showDialogPickFromDate(this, Utils.getCalendarDate(tvFromDate.text.toString()), object : DialogUtils.CallbackPickDateDialog {
                        override fun onPick(view: DatePicker, year: Int, monthOfYear: Int, dayOfMonth: Int) {
                            tvFromDate.text = String.format("%02d", dayOfMonth) + "/" + String.format("%02d", monthOfYear + 1) + "/" + year
                        }
                    }, null)
                else
                    DialogUtils.showDialogPickFromDate(this, Utils.getCalendarDate(tvFromDate.text.toString()), object : DialogUtils.CallbackPickDateDialog {
                        override fun onPick(view: DatePicker, year: Int, monthOfYear: Int, dayOfMonth: Int) {
                            tvFromDate.text = String.format("%02d", dayOfMonth) + "/" + String.format("%02d", monthOfYear + 1) + "/" + year
                        }
                    }, Utils.getCalendarDate(tvToDate.text.toString()))
            }
            R.id.tvToDate -> {
                DialogUtils.showDialogPickToDate(this, Utils.getCalendarDate(tvToDate.text.toString()), object : DialogUtils.CallbackPickDateDialog {
                    override fun onPick(view: DatePicker, year: Int, monthOfYear: Int, dayOfMonth: Int) {
                        tvToDate.text = String.format("%02d", dayOfMonth) + "/" + String.format("%02d", monthOfYear + 1) + "/" + year
                    }
                }, Utils.getCalendarDate(tvFromDate.text.toString()))
            }
            R.id.btnConfirm -> {
                if (report?.status == ReportStatus.NOT_CONFIRM.status) {
                    if (checkValidate())
                        confirmReport(report?.id)
                } else
                    completeReport(report?.id)
            }

        }
    }

    fun confirmReport(id: Int?) {
        setLoading(true)
        var nTescoRequestPOST = NTescoRequestPOST()
        nTescoRequestPOST.fromDate = tvFromDate.text.toString()
        nTescoRequestPOST.toDate = tvToDate.text.toString()
        ServiceFactory.createRetrofitService(NTescoService::class.java, Constant.apiEndPoint)
                .confirmReport(id, nTescoRequestPOST)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe(object : Observer<NTescoResponse> {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        setLoading(false)
                    }

                    override fun onNext(nTescoResponse: NTescoResponse) {
                        setLoading(false)
                        if (nTescoResponse.code == Constant.SUCCESS) {
                            sendBroadcast(ReportStatus.CONFIRM.status)
                            showAlertCallback(nTescoResponse.msg, object : DialogUtils.CallbackDialog {
                                override fun onCancel() {

                                }

                                override fun onAccept() {
//                                    val intent = Intent()
//                                    intent.putExtra(Constant.STATUS, ReportStatus.CONFIRM.status)
//                                    setResult(Activity.RESULT_OK, intent)
                                    finish()
                                }
                            })
                        }


                    }

                })
    }

    fun completeReport(id: Int?) {
        setLoading(true)
        ServiceFactory.createRetrofitService(NTescoService::class.java, Constant.apiEndPoint)
                .completeReport(id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe(object : Observer<NTescoResponse> {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        setLoading(false)
                    }

                    override fun onNext(nTescoResponse: NTescoResponse) {
                        setLoading(false)
                        if (nTescoResponse.code == Constant.SUCCESS) {
                            sendBroadcast(ReportStatus.COMPLETED.status)
                            showAlertCallback(nTescoResponse.msg, object : DialogUtils.CallbackDialog {
                                override fun onCancel() {

                                }

                                override fun onAccept() {
                                    finish()
                                }
                            })
                        }


                    }

                })
    }

    fun checkValidate(): Boolean {
        if (tvFromDate.text.toString().isEmpty()) {
            showAlert(getString(R.string.from_date_is_not_select))
            return false
        }
        if (tvToDate.text.toString().isEmpty()) {
            showAlert(getString(R.string.to_date_is_not_select))
            return false
        }
        return true
    }

    fun sendBroadcast(status: Int) {
        val intent = Intent(Constant.LIST_WORK_LOCAL_BROADCAST)
        intent.putExtra(Constant.STATUS, status)
        intent.putExtra(Constant.REPORT_ID, report?.id)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }
}
