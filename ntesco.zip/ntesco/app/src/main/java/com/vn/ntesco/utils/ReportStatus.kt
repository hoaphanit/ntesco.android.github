package com.vn.ntesco.utils

enum class ReportStatus(val status: Int) {
    NOT_CONFIRM(1),
    CONFIRM(2),
    COMPLETED(3),
    CANCEL(4),
    PROCESSING(5)


}