package com.vn.ntesco.adapter.adaptersViewPager

import android.content.Context
import android.support.annotation.NonNull
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.support.v7.widget.CardView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.jsibbold.zoomage.ZoomageView
import com.squareup.picasso.Picasso
import com.vn.ntesco.R
import com.vn.ntesco.utils.DimensionUtils
import ozaydin.serkan.com.image_zoom_view.ImageViewZoom

class ViewFullImageAdapterViewPager(private val mContext: Context,  var imageList:MutableList<String> ) : PagerAdapter() {

    override fun instantiateItem(view: ViewGroup, position: Int): Any {
        val imageLayout = LayoutInflater.from(mContext).inflate(R.layout.view_image_layout, view, false)!!
        val imageView = imageLayout.findViewById(R.id.image_view_full) as ZoomageView
        Picasso.get().load(R.drawable.bg_home).into(imageView)
        view.addView(imageLayout)
        return imageLayout
    }

    override fun getCount(): Int {
        return imageList.size
    }

    override fun isViewFromObject(@NonNull view: View, @NonNull `object`: Any): Boolean {
        return view == `object`
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }
}