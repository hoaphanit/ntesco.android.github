package com.vn.ntesco.activity

import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.text.InputType
import android.view.View
import android.widget.EditText
//import com.github.dhaval2404.imagepicker.ImagePicker
import com.vn.ntesco.R
import com.vn.ntesco.adapter.ReportCheckAdapter
import com.vn.ntesco.adapter.ReportUploadImages
import com.vn.ntesco.base.BaseHeaderActivity
import com.vn.ntesco.listener.ItemClickListener
import com.vn.ntesco.model.RawWaterType
import com.vn.ntesco.model.Request.NTescoRequestGET
import com.vn.ntesco.model.Response.ReportDetailReponse
import com.vn.ntesco.network.NTescoService
import com.vn.ntesco.network.ServiceFactory
import com.vn.ntesco.utils.*
import kotlinx.android.synthetic.main.activity_detail_report.*
import rx.Observer
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
//import net.gotev.uploadservice.UploadNotificationConfig
//import net.gotev.uploadservice.MultipartUploadRequest
import net.gotev.uploadservice.*
import android.provider.Settings
import android.support.design.widget.Snackbar
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.RecyclerView
import android.widget.ImageView
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson
import com.vn.ntesco.fragment.AddAddressDialogFragment
import com.vn.ntesco.model.Response.NTescoResponse
import java.io.FileOutputStream
import java.net.URISyntaxException


class CreateReportActivity : BaseHeaderActivity(), SharedPreferences.OnSharedPreferenceChangeListener, LocationData.AddressCallBack, ImagePicker.OnSingleImageSelectedListener {


    lateinit var waterTypeAdapter: ReportCheckAdapter
    lateinit var productTypeAdapter: ReportCheckAdapter
    lateinit var reportUploadImages: ReportUploadImages
    lateinit var edtCustomerName: EditText
    lateinit var edtContent: EditText
    var isDetail = false
    var posSelect: Int = 0
    lateinit var myReceiver: MyReceiver
    var mService: LocationUpdatesService? = null
    var mBound = false;
    var images = ArrayList<String>()
    var lat: Double = 0.0
    var lng: Double = 0.0

    private val mServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName,
                                        service: IBinder) {
            val binder = service as LocationUpdatesService.LocalBinder
            mService = binder.service
            mBound = true
        }

        override fun onServiceDisconnected(name: ComponentName) {
            mService = null;
            mBound = false
        }
    }


    override fun getLayoutContent(): Int {
        return R.layout.activity_detail_report
    }


    override fun setBackgroundHeader(): Int {
        return R.color.blue
    }

    override fun setTitle(): String {
        return resources.getString(R.string.report) + " (" + Utils.getCurrentDate() + ")"
    }

    override fun onStart() {
        super.onStart()
        //PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(this);


        bindService(Intent(this, LocationUpdatesService::class.java), mServiceConnection, Context.BIND_AUTO_CREATE)

    }


    override fun onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver,
                IntentFilter(LocationUpdatesService.ACTION_BROADCAST));
    }

    override fun onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver);
        super.onPause();
    }

    override fun onStop() {
        if (mBound) {
            // Unbind from the service. This signals to the service that this activity is no longer
            // in the foreground, and the service can respond by promoting itself to a foreground
            // service.
            unbindService(mServiceConnection);
            mBound = false;
        }
//        PreferenceManager.getDefaultSharedPreferences(this)
//                .unregisterOnSharedPreferenceChangeListener(this);
        super.onStop();
    }


    /**
     * Returns the current state of the permissions needed.
     */


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        WriteLog.i("TAG", "onRequestPermissionResult");
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.size <= 0) {
                // If user interaction was interrupted, the permission request is cancelled and you
                // receive empty arrays.
                WriteLog.i("TAG", "User interaction was cancelled.");
            } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted.
                mService?.requestLocationUpdates()
            } else {
                // Permission denied.
//                setButtonsState(false);
                Snackbar.make(
                        findViewById<View>(R.id.btnGetCurrent),
                        R.string.permission_denied_explanation,
                        Snackbar.LENGTH_INDEFINITE)
                        .setAction(R.string.settings, View.OnClickListener() {
                            val intent = Intent();
                            intent.setAction(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            val uri = Uri.fromParts("package",
                                    BuildConfig.APPLICATION_ID, null);
                            intent.setData(uri);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        })
                        .show();
            }
        }
    }


    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        // Update the buttons state depending on whether location updates are being requested.
        //  if (key.equals(Utils.KEY_REQUESTING_LOCATION_UPDATES)) {
//            setButtonsState(sharedPreferences?.getBoolean(Utils.KEY_REQUESTING_LOCATION_UPDATES,
//                false));
        //  }
    }


    override fun setBody(savedInstanceState: Bundle?) {
        super.setBody(savedInstanceState)
        // StatusBarCompat.translucentStatusBar(this, false  );
        //  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        myReceiver = MyReceiver()
        waterTypeAdapter = ReportCheckAdapter(this)
        productTypeAdapter = ReportCheckAdapter(this)
        reportUploadImages = ReportUploadImages(this)
        edtCustomerName = findViewById(R.id.txtCustomerName)
        // edtCustomerName.setText(UserCache.userInfo?.getFullName())
        edtContent = findViewById(R.id.edtContent)
        // getRawWaterTypes()

        reportUploadImages.listImages = images
        val linearLayoutManager = LinearLayoutManager(this@CreateReportActivity, GridLayoutManager.HORIZONTAL, false)
        rvImageReport.apply {
            setHasFixedSize(true)
            adapter = reportUploadImages
            layoutManager = linearLayoutManager

        }
        rvImageReport.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (images.size >= 3) {
                    val layoutManager = recyclerView.getLayoutManager() as LinearLayoutManager;
                    val pos = layoutManager?.findLastCompletelyVisibleItemPosition();
                    val numItems = recyclerView.getAdapter()?.getItemCount();
                    WriteLog.e("isLastVisible", pos.toString())
                    WriteLog.e("isLastVisible", numItems.toString())
                    if(pos==0){
                        ivPrevious.visibility= View.GONE
                    }else{
                        ivPrevious.visibility= View.VISIBLE
                    }
                    if(pos+1 >= numItems!!) {
                        ivNext.visibility= View.GONE
                    }else{
                        ivNext.visibility= View.VISIBLE
                    }
                }else{
                    ivPrevious.visibility= View.GONE
                    ivNext.visibility= View.GONE
                }
            }
        })
        rvReportWaterType.apply {
            setHasFixedSize(true)
            adapter = waterTypeAdapter
            layoutManager = GridLayoutManager(this@CreateReportActivity, 2, GridLayoutManager.VERTICAL, false)
            waterTypeAdapter.data = PrefUtils.getInstance().getListWaterType()
            waterTypeAdapter.notifyDataSetChanged()
        }
        rvReportProducts.apply {
            setHasFixedSize(true)
            adapter = productTypeAdapter
            layoutManager = GridLayoutManager(this@CreateReportActivity, 2, GridLayoutManager.VERTICAL, false)
            productTypeAdapter.data = PrefUtils.getInstance().getListProduct()
            productTypeAdapter.notifyDataSetChanged()
        }
        reportUploadImages.setOnItemClickListener(object : ItemClickListener {
            override fun <T : Any> onItemClick(item: T, position: Int) {
                posSelect = position
//                if (images[position].isEmpty()) {
//                    ImagePicker.with(this@CreateReportActivity)
//                            .crop(1f, 1f)                //Crop Square icon(Optional)
//                            .compress(1024)            //Final icon size will be less than 1 MB(Optional)
//                            .maxResultSize(1080, 1080)    //Final icon resolution will be less than 1080 x 1080(Optional)
//                            .start()
//                }
                if (images[position].isEmpty()) {
                    val imagePicker = ImagePicker.Builder("ntesco.fileprovider").build()
                    imagePicker.show(supportFragmentManager, "picker")
                }
            }

        })


        btnSubmit.setOnClickListener(View.OnClickListener {
            if (checkValidate())
                uploadReport()
        })
        txtAddress.setOnClickListener(View.OnClickListener {
            val addAddressDialogFragment = AddAddressDialogFragment.builder(object : AddAddressDialogFragment.CallbackPopup {
                override fun onSelectClick(address: String, latLng: LatLng?) {
                    txtAddress.setText(address)
                    lat = latLng?.latitude!!
                    lng = latLng?.longitude!!
                }


            })
            addAddressDialogFragment.showOnActivity(this)
            // var it = Intent(CreateReportActivity@ this, AddAddressDialog::class.java)
            //   startActivityForResult(it, 500)
        })
        images.add("")
        btnGetCurrent.setOnClickListener(
                {
                    if (!checkPermissions()) {
                        requestPermissions();
                    } else {
                        setLoading(true)
                        mService?.requestLocationUpdates();
                    }
                })
//        if (this@CreateReportActivity.intent.hasExtra(Constant.REPORT)) {
//            val report = intent.getSerializableExtra(Constant.REPORT) as Report
//            txtAddress.setOnClickListener(null)
//            isDetail = report != null
//            titleHeader.text = getString(R.string.report) + " (" + report?.publishDate + ")"
//            getReportDetail(report?.id ?: 0)
//            readOnly(edtCustomerName)
//            readOnly(edtContent)
//            llGetLocation.visibility = View.INVISIBLE
//            labelUpload.visibility = View.GONE
//            btnSubmit.visibility = View.GONE
//        } else {
//            images.add("")
//        }
//        txtCustomerName.setText((UserCache?.userInfo?.lastName!! +" "+  UserCache?.userInfo?.firstName!!))

//        if (PrefUtils.getInstance().getLanguage().equals("en"))
        txtCustomerName.setText((UserCache?.userInfo?.lastName!! +" "+  UserCache?.userInfo?.firstName!!))
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == 500) {
            txtAddress.setText(data?.extras?.get(Constant.ADDRESS).toString())
            val latLng: LatLng = data?.extras?.getParcelable(Constant.LAT_LNG) as LatLng
            lat = latLng.latitude
            lng = latLng.longitude
            // WriteLog.e("adddddressssssss", latLng.latitude.toString() + " " + latLng.longitude.toString())
            return
        }

//        if (resultCode == Activity.RESULT_OK) {
//            //Image Uri will not be null for RESULT_OK
//            val fileUri = data?.data
////            imgProfile.setImageURI(fileUri)
//
//            //You can get File object from intent
//            val file: File? = ImagePicker.getFile(data!!)
//
//            //You can also get File Path from intent
//            val filePath: String? = ImagePicker.getFilePath(data)
//            WriteLog.e("pathhhhhhhh", filePath)
//            images[posSelect] = filePath!!
//            images.add("")
////            reportUploadImages.listImages[posSelect]= filePath!!
//            reportUploadImages.notifyDataSetChanged()
//            rvImageReport.scrollToPosition(reportUploadImages.listImages.size - 1)
//        } else if (resultCode == ImagePicker.RESULT_ERROR) {
//            // Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
//        } else {
//            // Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
//        }
    }

    override fun onSingleImageSelected(uri: Uri?, tag: String?) {
        var imgPath: String? = null
        try {
            imgPath = ImageUtils.getPathImage(this, uri!!)
        } catch (e: URISyntaxException) {
            e.printStackTrace()
        }

        if (imgPath == null) return
        setLoading(true)
        Thread(Runnable {
            var bitmap: Bitmap? = null
            try {
                bitmap = ImageUtils.resizeBitmap(imgPath)
                val out = FileOutputStream(imgPath)
                bitmap?.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
                out.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            runOnUiThread(Runnable {
                setLoading(false)
                if (bitmap == null) {
                    return@Runnable
                }
                images[posSelect] = imgPath!!
                images.add("")
                reportUploadImages.notifyDataSetChanged()
                rvImageReport.scrollToPosition(reportUploadImages.listImages.size - 1)
            })
        }).start()
    }

    private fun getReportDetail(id: Int) {
        setLoading(true)
        var ntescoRequest = NTescoRequestGET()
        ServiceFactory.createRetrofitService(NTescoService::class.java, Constant.apiEndPoint)
                .getDetailReport(id.toString(), ntescoRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe(object : Observer<ReportDetailReponse> {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        setLoading(false)
                    }

                    override fun onNext(reportDetailReponse: ReportDetailReponse) {
                        setLoading(false)
                        if (reportDetailReponse.code == Constant.SUCCESS) {
                            edtCustomerName.setText(reportDetailReponse.data?.customerName)
                            edtContent.setText(reportDetailReponse.data?.error)
                            txtAddress.setText(reportDetailReponse.data?.address)
                            edtContent.setSelection(edtContent.text.toString().length)
                            edtCustomerName.setSelection(edtCustomerName.text.toString().length)



                            waterTypeAdapter.isDetail = true
                            waterTypeAdapter.data = reportDetailReponse.data?.rawWaterType as ArrayList<RawWaterType>
                            waterTypeAdapter.notifyDataSetChanged()

                            productTypeAdapter.isDetail = true
                            productTypeAdapter.data = reportDetailReponse.data?.products as ArrayList<RawWaterType>
                            productTypeAdapter.notifyDataSetChanged()

                            reportUploadImages.listImages = reportDetailReponse.data?.images
                            reportUploadImages.notifyDataSetChanged()


                        }

                    }

                })
    }

    private fun readOnly(editText: EditText) {
        editText.isFocusable = false
        editText.isFocusableInTouchMode = false
        editText.inputType = InputType.TYPE_NULL
    }

    private fun uploadReport() {
        setLoading(true)
        var multipartUploadRequest = MultipartUploadRequest(this, Constant.apiEndPoint+"/api/customer/send-report")
        try {
            for (image in images) {
                multipartUploadRequest.addFileToUpload(image, "images[]")

            }
        } catch (exc: Exception) {
            WriteLog.e("AndroidUploadService", exc.message)
        }
        for (raw_water in waterTypeAdapter.data) {
            if (raw_water.select) {
                multipartUploadRequest.addParameter("raw_water_type[]", raw_water.id.toString())
            }
        }

        for (product in productTypeAdapter.data) {
            if (product.select) {
                multipartUploadRequest.addParameter("products[]", product.id.toString())
            }
        }
        multipartUploadRequest.addHeader("Content-Type", "application/json")
        multipartUploadRequest.addHeader("Authorization", "Bearer " + UserCache.userInfo?.accessToken)
        multipartUploadRequest.addHeader("Language", Constant.getLanguage())

        multipartUploadRequest.addParameter("customer_name", edtCustomerName.text.toString())
        multipartUploadRequest.addParameter("error", edtContent.text.toString())
        multipartUploadRequest.addParameter("address", txtAddress.text.toString())
        multipartUploadRequest.addParameter("lat", lat.toString())
        multipartUploadRequest.addParameter("lng", lng.toString())
        val config = UploadNotificationConfig()
        config.completed.autoClear = true
        multipartUploadRequest.setNotificationConfig(config)
        multipartUploadRequest.setDelegate(object : UploadStatusDelegate {
            override fun onProgress(context: Context?, uploadInfo: UploadInfo?) {
                WriteLog.e("onCompleted", uploadInfo.toString())

            }

            override fun onError(context: Context?, uploadInfo: UploadInfo?, serverResponse: ServerResponse?, exception: java.lang.Exception?) {
                WriteLog.e("onError", serverResponse?.bodyAsString)
                setLoading(false)

            }

            override fun onCompleted(context: Context?, uploadInfo: UploadInfo?, serverResponse: ServerResponse?) {
                WriteLog.e("onCompleted", serverResponse?.getBodyAsString())
                setLoading(false)
                if (serverResponse?.bodyAsString != null) {
                    val nTescoResponse = Gson().fromJson(serverResponse?.bodyAsString, NTescoResponse::class.java);
                    if (nTescoResponse.code == Constant.SUCCESS) {
                        showAlertCallback(nTescoResponse.msg, object : DialogUtils.CallbackDialog {
                            override fun onCancel() {

                            }

                            override fun onAccept() {
                                setResult(Activity.RESULT_OK)
                                finish()
                            }
                        })

                    } else
                        showAlert(nTescoResponse.msg)
                }
            }

            override fun onCancelled(context: Context?, uploadInfo: UploadInfo?) {
                setLoading(false)
            }
        })
        multipartUploadRequest.setUtf8Charset()
        multipartUploadRequest.setMaxRetries(2)
        multipartUploadRequest.startUpload()

    }

    inner class MyReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val location: Location = intent?.extras!!.getParcelable(LocationUpdatesService.EXTRA_LOCATION);
            if (location != null) {
                mService?.removeLocationUpdates()
                WriteLog.e("location", location.toString())
                lat = location.latitude
                lng = location.longitude
                if (Utils.isNetworkConnected(this@CreateReportActivity)) {
                    val getLocationDetail = GetLocationDetail(this@CreateReportActivity, this@CreateReportActivity)
                    getLocationDetail.getAddress(location.latitude, location.longitude, "AIzaSyAXjssHBlyvnt57SDuBy219QbSGACwJfr8")
                } else {
                    showAlert(getString(R.string.network_error))
                }
                setLoading(false)

            }
        }

    }

    override fun locationData(locationData: LocationData?) {
        WriteLog.e("location:::::", locationData?.full_address)
        //  setLoading(false)
        txtAddress.setText(locationData?.full_address)
    }

    fun checkValidate(): Boolean {
        if (edtCustomerName.text.toString().isEmpty() || edtCustomerName.text.toString().trim().isEmpty()) {
            showAlert(getString(R.string.customer_name_is_empty))
            return false
        }
        var countRaw: Int = 0
        for (raw_water in waterTypeAdapter.data) {
            if (raw_water.select) {
                break
            } else {
                countRaw++
                if (countRaw == waterTypeAdapter.data.size) {
                    showAlert(getString(R.string.raw_water_is_not_selected))
                    return false
                }
            }
        }
        var countProduct: Int = 0
        for (product in productTypeAdapter.data) {
            if (product.select) {
                break
            } else {
                countProduct++
                if (countProduct == productTypeAdapter.data.size) {
                    showAlert(getString(R.string.product_is_not_selected))
                    return false
                }
            }
        }
        if (reportUploadImages.listImages.size <= 1) {
            showAlert(getString(R.string.image_error_is_not_uploaded))
            return false
        }
        if (edtContent.text.toString().isEmpty() || edtContent.text.toString().trim().isEmpty()) {
            showAlert(getString(R.string.error_report_is_empty))
            return false
        }
        if (txtAddress.text.toString().isEmpty() || txtAddress.text.toString().trim().isEmpty()) {
            showAlert(getString(R.string.location_is_not_selected))
            return false
        }
        return true
    }


}
