package com.vn.ntesco.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.vn.ntesco.R
import com.vn.ntesco.listener.ItemClickListener
import com.vn.ntesco.model.Notification
import android.content.Context
import android.support.v4.content.ContextCompat
import android.widget.ImageView

class NotificationAdapter(val mContext: Context?) : RecyclerView.Adapter<NotificationAdapter.ViewHolder>() {

    lateinit var itemClickListener: ItemClickListener
    var notificationsList: MutableList<Notification> = ArrayList<Notification>()

    override fun getItemCount(): Int {
        return notificationsList.size;
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_notification, parent, false))
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        viewHolder.itemView.setOnClickListener(View.OnClickListener {
            if (itemClickListener != null)
                itemClickListener!!.onItemClick(notificationsList[position], position)
        })
        if (notificationsList[position].status == 1) {
            viewHolder.ivNotify.setImageResource(R.mipmap.ic_notify_new)
        } else {
            viewHolder.ivNotify.setImageResource(R.mipmap.ic_notify)
        }
        viewHolder.tvTitle.setText(notificationsList[position].title)
        viewHolder.tvDateCreated.setText(notificationsList[position].createdAt)
    }


    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        lateinit var tvTitle: TextView
        lateinit var tvDateCreated: TextView
        lateinit var ivNotify: ImageView

        init {
            tvTitle = v.findViewById(R.id.tvTitleNotify)
            tvDateCreated = v.findViewById(R.id.tvDateNotify)
            ivNotify = v.findViewById(R.id.ivIconNotify)

        }


    }

    fun setOnItemClickListener(itemClickListener: ItemClickListener) {
        this.itemClickListener = itemClickListener
    }
}