package com.vn.ntesco.views

import android.content.Context
import android.support.annotation.Nullable
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.View

class CustomeViewPager: ViewPager{

    constructor(context: Context) : super(context) {}

    constructor(context: Context, @Nullable attrs: AttributeSet) : super(context, attrs) {
    }

    override fun requestChildFocus(child: View, focused: View) {
        //Do nothing, disables automatic focus behaviour

    }

}