package com.vn.ntesco.model

import com.google.gson.annotations.SerializedName

data class Chemicals (
    @SerializedName("id")
    var id: Int = 0,
    @SerializedName("name")
    var name: String = "",
    @SerializedName("type")
    var type: Int = 0
)

