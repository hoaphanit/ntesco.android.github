package com.vn.ntesco.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.vn.ntesco.R
import com.vn.ntesco.adapter.ListReportAdapter
import com.vn.ntesco.base.BaseHeaderActivity
import com.vn.ntesco.listener.EndlessRecyclerOnScrollListener
import com.vn.ntesco.listener.ItemClickListener
import com.vn.ntesco.model.Report
import com.vn.ntesco.model.Request.NTescoRequestGET
import com.vn.ntesco.model.Response.ReportResponse
import com.vn.ntesco.network.NTescoService
import com.vn.ntesco.network.ServiceFactory
import com.vn.ntesco.utils.Constant
import kotlinx.android.synthetic.main.activity_report.*
import rx.Observer
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class ReportActivity : BaseHeaderActivity(), SwipeRefreshLayout.OnRefreshListener {


    private lateinit var listReportAdapter: ListReportAdapter
    val CREATE_REPORT_REQUEST = 123
    lateinit var endlessRecyclerOnScrollListener: EndlessRecyclerOnScrollListener
    override fun setTitle(): String {
        return resources.getString(R.string.report)
    }

    override fun getLayoutContent(): Int {
        return R.layout.activity_report
    }

    override fun setBackgroundHeader(): Int {
        return R.color.blue
    }

    override fun setBody(savedInstanceState: Bundle?) {
        super.setBody(savedInstanceState)
        listReportAdapter = ListReportAdapter(this)

        listReportAdapter.setOnItemClickListener(object : ItemClickListener {
            override fun <T : Any> onItemClick(item: T, position: Int) {
//                val report = listReportAdapter.data[position].id
//                val intent = Intent(this@ReportActivity, CreateReportActivity::class.java)
//                intent.putExtra(Constant.REPORT, item as Report)
//                startActivity(intent)
                val intent = Intent(this@ReportActivity, DetailWorkActivity::class.java)
                intent.putExtra(Constant.REPORT, item as? Report)
                startActivity(intent)
            }

        })
        tvAdd.visibility = View.VISIBLE
        val linearLayoutManager = LinearLayoutManager(this@ReportActivity)

        rvReport.apply {
            layoutManager = linearLayoutManager
            adapter = listReportAdapter
        }
        swipeRefreshLayout.setOnRefreshListener(this)
        endlessRecyclerOnScrollListener = object : EndlessRecyclerOnScrollListener(linearLayoutManager, Constant.DEFAULT_FIRST_PAGE) {
            override fun onLoadMore(current_page: Int) {
                getReports(current_page)
            }

        }
        rvReport.addOnScrollListener(endlessRecyclerOnScrollListener)
        getReports(Constant.DEFAULT_FIRST_PAGE)
        if (intent.hasExtra(Constant.REPORT_ID)) {
            startDetail(intent)
        }
    }
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null && intent.hasExtra(Constant.REPORT_ID)) {
            onRefresh()
            startDetail(intent)
        }
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.txtAdd -> {
                val intent = Intent(this, CreateReportActivity::class.java)
                startActivityForResult(intent, CREATE_REPORT_REQUEST)
            }
        }
    }
    fun startDetail(intent: Intent?) {
        val intentStart = Intent(this, DetailWorkActivity::class.java)
        intentStart.putExtra(Constant.REPORT_ID, intent?.getIntExtra(Constant.REPORT_ID, 0))
        startActivity(intentStart)
    }
    override fun onRefresh() {
        swipeRefreshLayout.isRefreshing = false
        endlessRecyclerOnScrollListener?.resetCurrentPage()
        getReports(Constant.DEFAULT_FIRST_PAGE)
    }

    private fun getReports(page: Int) {
        setLoading(true)
        var ntescoRequest = NTescoRequestGET()
        ntescoRequest.setPage(page)
        ServiceFactory.createRetrofitService(NTescoService::class.java, Constant.apiEndPoint)
                .getReport(ntescoRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe(object : Observer<ReportResponse> {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        setLoading(false)
                    }

                    override fun onNext(reportResponse: ReportResponse) {
                        setLoading(false)
                        if (reportResponse.code == Constant.SUCCESS) {
                            reportResponse.data?.let {
                                if (page == Constant.DEFAULT_FIRST_PAGE) {
                                    listReportAdapter.data = reportResponse.data.data
                                    if (reportResponse.data.data.size == 0)
                                        tvNodata.visibility = View.VISIBLE
                                    else
                                        tvNodata.visibility = View.GONE
                                } else
                                    listReportAdapter.data.addAll(reportResponse.data.data)
                                listReportAdapter.notifyDataSetChanged()

                            }


                        }

                    }

                })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_REPORT_REQUEST && resultCode == Activity.RESULT_OK) {
            onRefresh()
        }
    }

}
