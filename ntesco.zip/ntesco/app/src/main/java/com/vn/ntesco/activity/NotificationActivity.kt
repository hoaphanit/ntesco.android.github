package com.vn.ntesco.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.vn.ntesco.R
import com.vn.ntesco.base.BaseHeaderActivity
import com.vn.ntesco.fragment.ListWorkFragment
import com.vn.ntesco.fragment.NotificationFragment
import com.vn.ntesco.fragment.SignUpFragment
import com.vn.ntesco.utils.Constant
import com.vn.ntesco.utils.UserCache

class NotificationActivity : BaseHeaderActivity() {

    override fun setTitle(): String {
        return resources.getString(R.string.notification)
    }

    override fun getLayoutContent(): Int {
        return R.layout.activity_notification
    }

    override fun setBackgroundHeader(): Int {
        return UserCache.getColorUser()
    }

    override fun setBody(savedInstanceState: Bundle?) {
        super.setBody(savedInstanceState)
        replaceFragment(NotificationFragment())
        if (intent.hasExtra(Constant.NOTIFICATION_ID)) {
            startDetail(intent)
        }
    }
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null && intent.hasExtra(Constant.REPORT_ID)) {
            startDetail(intent)
        }
    }

    fun startDetail(intent: Intent?) {
        val intentStart = Intent(this, DetailNotificationActivity::class.java)
        intentStart.putExtra(Constant.NOTIFICATION_ID, intent?.getIntExtra(Constant.NOTIFICATION_ID, 0))
        startActivity(intentStart)
    }
}
