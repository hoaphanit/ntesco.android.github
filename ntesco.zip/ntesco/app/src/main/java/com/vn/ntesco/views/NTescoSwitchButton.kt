package com.vn.ntesco.views

import android.content.Context
import android.support.annotation.Nullable
import android.support.v4.content.ContextCompat
import android.support.v7.widget.CardView
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.vn.ntesco.R


class NTescoSwitchButton : FrameLayout {
    internal var clickListener: ClickListener? = null
    lateinit var tvLeft : TextView
    lateinit var tvRight : TextView

    var isDisable: Boolean = false
    var isLeft: Boolean = true
    fun setClickListener(clickListener: ClickListener) {
        this.clickListener = clickListener
    }

    constructor(context: Context) : super(context) {
        init(null)
    }

    constructor(context: Context, @Nullable attrs: AttributeSet) : super(context, attrs) {
        init(attrs)
    }

    constructor(context: Context, @Nullable attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init(attrs)
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int, defStyleRes: Int) : super(context, attrs, defStyleAttr, defStyleRes) {
        init(attrs)
    }


    fun init(attr: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attr, R.styleable.NTescoSwitchButton)
        val view = LayoutInflater.from(context).inflate(R.layout.switch_button_layout, this, false)
        tvLeft = view.findViewById(R.id.leftSwitchButton)
        tvRight = view.findViewById(R.id.rightSwitchButton)
        val cardView = view.findViewById(R.id.cardView) as CardView
        tvLeft.setText(attributes.getString(R.styleable.NTescoSwitchButton_left_text))
        tvRight.setText(attributes.getString(R.styleable.NTescoSwitchButton_right_text))
        tvLeft.setOnClickListener(OnClickListener {
            if(isDisable) return@OnClickListener
            tvLeft.setTextColor(ContextCompat.getColor(context, R.color.white))
            tvLeft.setBackgroundResource(R.drawable.bg_corner_red)
            tvRight.setTextColor(ContextCompat.getColor(context, R.color.black_49))
            tvRight.setBackgroundResource(0)
            isLeft= true
            if (clickListener != null)
                clickListener?.onLeftClick()

        })
        tvRight.setOnClickListener(OnClickListener {
            if(isDisable) return@OnClickListener
            isLeft= false
            tvLeft.setTextColor(ContextCompat.getColor(context, R.color.black_49))
            tvLeft.setBackgroundResource(0)
            tvRight.setTextColor(ContextCompat.getColor(context, R.color.white))
            tvRight.setBackgroundResource(R.drawable.bg_corner_red)
            if (clickListener != null)
                clickListener?.onRightClick()
        })


        val width = attributes.getInt(R.styleable.NTescoSwitchButton_layout_weight, 0)
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        when (width) {
            0 -> {
                params.weight = 0f
                tvLeft.layoutParams = params
                tvRight.layoutParams = params
            }
            else -> {
                params.weight = 1.0f
                tvLeft.layoutParams = params
                tvRight.layoutParams = params
            }
        }
        attributes.recycle()
        addView(view)
    }
    fun setLeftSelect(){
        tvLeft.setTextColor(ContextCompat.getColor(context, R.color.white))
        tvLeft.setBackgroundResource(R.drawable.bg_corner_red)
        tvRight.setTextColor(ContextCompat.getColor(context, R.color.black_49))
        tvRight.setBackgroundResource(0)
    }
    fun setRigtSelect(){
        tvLeft.setTextColor(ContextCompat.getColor(context, R.color.black_49))
        tvLeft.setBackgroundResource(0)
        tvRight.setTextColor(ContextCompat.getColor(context, R.color.white))
        tvRight.setBackgroundResource(R.drawable.bg_corner_red)
    }
    interface ClickListener {
        fun onRightClick()
        fun onLeftClick()
    }
}