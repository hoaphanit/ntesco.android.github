package com.vn.ntesco.listener

import java.util.*

interface ItemClickListener {
    abstract fun <T : Any> onItemClick(item: T, position: Int)
}