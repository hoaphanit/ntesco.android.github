package com.vn.ntesco.activity

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.AppBarLayout
import android.support.design.widget.CollapsingToolbarLayout
import android.support.v4.content.ContextCompat
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.ImageView
import com.squareup.picasso.Picasso
import com.vn.ntesco.R
import com.vn.ntesco.base.BaseActivity
import com.vn.ntesco.model.Post
import com.vn.ntesco.model.Request.NTescoRequestGET
import com.vn.ntesco.model.Response.DetailPostResponse
import com.vn.ntesco.model.Response.PostResponse
import com.vn.ntesco.network.NTescoService
import com.vn.ntesco.network.ServiceFactory
import com.vn.ntesco.utils.Constant
import kotlinx.android.synthetic.main.activity_detail_post.*
import qiu.niorgai.StatusBarCompat
import rx.Observer
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class DetailPostActivity : BaseActivity(), AppBarLayout.OnOffsetChangedListener, View.OnClickListener {

    lateinit var main_collapsing: CollapsingToolbarLayout
    lateinit var mAppbar: AppBarLayout
    lateinit var mToolbar: Toolbar
    lateinit var ivBack: ImageView
    lateinit var bannerPost: ImageView
    lateinit var typePost: String
    lateinit var mPost: Post
    private val PERCENTAGE_TO_SHOW_BANNER = 40
    private var mMaxScrollSize: Int = 0

    override fun getLayoutResource(): Int {
        return R.layout.activity_detail_post
    }

    override fun setBody(savedInstanceState: Bundle?) {
        typePost = intent.getStringExtra(Constant.TYPE)

        mPost = intent.getSerializableExtra(Constant.POST) as Post
        main_collapsing = findViewById(R.id.main_collapsing)
        mAppbar = findViewById(R.id.main_appbar)
        ivBack = findViewById(R.id.ivBack)
        bannerPost = findViewById(R.id.bannerPost)
        mToolbar = findViewById(R.id.toolbar)
        mAppbar.addOnOffsetChangedListener(this)
        ivBack.setOnClickListener(this)
        initData(mPost)
        StatusBarCompat.setStatusBarColorForCollapsingToolbar(this, mAppbar, main_collapsing, mToolbar, Color.TRANSPARENT);
       // webViewContent.settings.useWideViewPort = true
        webViewContent.settings.javaScriptEnabled = true
      //  webViewContent.settings.loadWithOverviewMode = true
    }

    override fun onOffsetChanged(appBarLayout: AppBarLayout?, i: Int) {
        if (mMaxScrollSize == 0)
            mMaxScrollSize = appBarLayout!!.getTotalScrollRange()

        val currentScrollPercentage = Math.abs(i) * 100 / mMaxScrollSize

        if (currentScrollPercentage >= PERCENTAGE_TO_SHOW_BANNER) {
            if (typePost.equals(Constant.NEWS_EVENT)) {
                // StatusBarCompat.setStatusBarColorForCollapsingToolbar(this, mAppbar, main_collapsing, mToolbar, ContextCompat.getColor(this, R.color.green));
                StatusBarCompat.setStatusBarColor(this, ContextCompat.getColor(this, R.color.green));
                mToolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.green))
            } else {
                mToolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.blue_ocean))
                // StatusBarCompat.setStatusBarColorForCollapsingToolbar(this, mAppbar, main_collapsing, mToolbar,ContextCompat.getColor(this, R.color.blue_ocean));
                StatusBarCompat.setStatusBarColor(this, ContextCompat.getColor(this, R.color.blue_ocean));
            }
            //   ivBack.setBackgroundResource(0)
        } else {
            mToolbar.setBackgroundColor(Color.TRANSPARENT)
            // ivBack.setBackgroundResource(R.color.transparent_50)
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ivBack -> {
                finish()
            }
        }
    }

    fun initData(post: Post) {
        Picasso.get().load(post?.image).centerCrop().fit().placeholder(R.mipmap.default_banner).into(bannerPost)
        tvTitlePost.text = post?.name
        getDetailPost(post)
    }

    private fun getDetailPost(post: Post) {
        setLoading(true)
        ServiceFactory.createRetrofitService(NTescoService::class.java, Constant.apiEndPoint)
                .getDetailPost(post?.id ?: 0)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread()).subscribe(object : Observer<DetailPostResponse> {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        setLoading(false)
                    }

                    override fun onNext(detailPostResponse: DetailPostResponse) {
                        setLoading(false)
                        if (detailPostResponse.code == Constant.SUCCESS) {
                            val content = ("<html><head>"
                                    + "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
                                  //  + "<style type=\"text/css\"> img{max-width: 100%, height: auto;}"
                                   // + "</style></head>"
                                    + "<body>"
                                    + detailPostResponse.data?.content
                                    + "</body></html>")
                            webViewContent.loadData(content, "text/html", "UTF-8")
                            tvNumberView.text = detailPostResponse.data?.views.toString()
                            tvDatePosting.text = detailPostResponse.data?.publishDate
                        }

                    }

                })
    }
}
