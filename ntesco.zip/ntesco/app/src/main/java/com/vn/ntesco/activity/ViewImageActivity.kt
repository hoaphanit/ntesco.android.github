package com.vn.ntesco.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v4.view.ViewPager
import android.widget.ImageView
import com.vn.ntesco.R
import com.vn.ntesco.adapter.adaptersViewPager.ViewFullImageAdapterViewPager
import com.vn.ntesco.base.BaseActivity
import com.vn.ntesco.utils.Constant
import kotlinx.android.synthetic.main.activity_view_image.*

class ViewImageActivity : BaseActivity(){
    lateinit var viewFullImageAdapterViewPager: ViewFullImageAdapterViewPager
    override fun getLayoutResource(): Int {
        return R.layout.activity_view_image
    }

    override fun setBody(savedInstanceState: Bundle?) {
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        var listImage : MutableList<String> = ArrayList<String>()
        if(intent.getStringArrayListExtra(Constant.LIST_IMAGE)!=null){
            listImage = intent.getStringArrayListExtra(Constant.LIST_IMAGE)
        }
        viewFullImageAdapterViewPager = ViewFullImageAdapterViewPager(this,listImage)
        vpViewImage.apply {
            adapter = viewFullImageAdapterViewPager
        }
        circleIndicator.setViewPager(vpViewImage)
        ivBack.setOnClickListener{
            finish()
        }
    }


}